# Open HTML in Default Browser

## 特点
- 用默认浏览器打开 HTML 文件
- 在资源管理器中，HTML 文件右键显示 `在浏览器中打开` 菜单
- 在编辑器中，HTML 文件右键显示 `在浏览器中打开` 菜单